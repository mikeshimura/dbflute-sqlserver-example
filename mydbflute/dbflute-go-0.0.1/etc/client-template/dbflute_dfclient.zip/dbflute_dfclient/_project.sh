#!/bin/bash

export ANT_OPTS=-Xmx512m

export DBFLUTE_HOME=../mydbflute/dbflute-go-0.0.1

export MY_PROPERTIES_PATH=build.properties
